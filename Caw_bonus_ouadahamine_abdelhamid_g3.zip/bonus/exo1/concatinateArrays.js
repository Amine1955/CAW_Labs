const numbers = [ 1, 2, 3 ];
const letters = [ "a", "b", "c" ]
const foods = ["mango", "pecan pie" ]

const ConcatenatedArrays = numbers.concat(letters, foods);
console.log(ConcatenatedArrays);