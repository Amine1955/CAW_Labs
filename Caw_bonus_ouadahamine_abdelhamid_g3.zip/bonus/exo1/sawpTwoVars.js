let v1  = 2;
let v2  = 8;

[v1 , v2] = [v2 , v1];

console.log("v1 = "+ v1 );
console.log("v2 = "+ v2 );