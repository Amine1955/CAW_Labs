let name = "Amine";

const spellYourName = [...name];

console.log(spellYourName);