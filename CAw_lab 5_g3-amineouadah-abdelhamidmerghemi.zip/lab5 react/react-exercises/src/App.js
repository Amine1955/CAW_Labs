import React, { useState } from 'react';
import DivForm from './components/exo4/DivForm';
import DivDisplay from './components/exo4/DivDisplay';

function App() {
  const [divs, setDivs] = useState([]);

  // Function to add a new div to the list
  const handleAddDiv = (div) => {
    setDivs((prevDivs) => [...prevDivs, div]);
  };

  return (
    <div className="app-container">
      <h1>Create and Display Divs</h1>
      <DivForm onAddDiv={handleAddDiv} />
      <DivDisplay divs={divs} />
    </div>
  );
}

export default App;
