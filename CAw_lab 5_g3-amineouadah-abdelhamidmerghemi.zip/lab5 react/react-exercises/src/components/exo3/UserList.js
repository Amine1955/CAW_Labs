import React from 'react';
import './AuthStyle.css'; // Reuse the CSS for the list

function UserList({ users, onDeleteUser }) {
  return (
    <div className="user-list-container">
      <h3>List of Users</h3>
      <ul className="user-list">
        {users.map((user, index) => (
          <li key={index} className="user-item">
            {user}
            <button
              className="delete-button"
              onClick={() => onDeleteUser(index)}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default UserList;
