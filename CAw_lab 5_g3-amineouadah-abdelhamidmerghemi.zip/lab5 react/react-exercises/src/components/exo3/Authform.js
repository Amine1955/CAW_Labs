import React, { useState } from 'react';
import './AuthStyle.css'; // New CSS for Exercise 3

function AuthForm({ onAddUser }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (username && password) {
      onAddUser(username, password);
      setUsername('');
      setPassword('');
    }
  };

  return (
    <div className="form-container">
      <h3>Authentication Form</h3>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button type="submit" className="submit-button">
          Add User
        </button>
      </form>
    </div>
  );
}

export default AuthForm;
