import React from 'react';
import './TableStyle.css'; // New CSS for Exercise 2

function DisplayTab({ tab, onRemoveItem }) {
  return (
    <div className="list-container">
      <h3>Table Display</h3>
      <ul className="styled-list">
        {tab.map((item, index) => (
          <li
            key={index}
            onClick={() => onRemoveItem(index)}
            className="list-item"
          >
            {`Element ${index + 1} is: ${item}`}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default DisplayTab;
