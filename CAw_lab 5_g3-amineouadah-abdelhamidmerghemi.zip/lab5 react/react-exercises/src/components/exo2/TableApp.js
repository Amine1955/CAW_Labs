import React, { useState } from 'react';
import DisplayTab from './DisplayTab';

function TableApp() {
  // Define two different tables
  const [table1, setTable1] = useState(['hello', 'world', 'from', 'react']);
  const [table2, setTable2] = useState(['this', 'is', 'another', 'table']);

  // Function to handle item removal for each table
  const handleRemoveItem = (table, setTable, index) => {
    const newTable = [...table];
    newTable.splice(index, 1); // Remove the clicked item
    setTable(newTable);
  };

  return (
    <div>
      <h2>Exercise 2: Table Display</h2>
      {/* Display first table */}
      <DisplayTab
        tab={table1}
        onRemoveItem={(index) => handleRemoveItem(table1, setTable1, index)}
      />

      {/* Display second table */}
      <DisplayTab
        tab={table2}
        onRemoveItem={(index) => handleRemoveItem(table2, setTable2, index)}
      />
    </div>
  );
}

export default TableApp;
