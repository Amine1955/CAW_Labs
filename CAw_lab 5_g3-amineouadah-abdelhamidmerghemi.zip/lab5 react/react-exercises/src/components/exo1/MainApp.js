import React, { useState } from 'react';
import './ButtonClick.css'; // Reuse the styles for consistency

function MainApp() {
  const [clickedButton, setClickedButton] = useState(null);

  const handleButtonClick = (buttonNumber) => {
    setClickedButton(buttonNumber);
  };

  return (
    <div className="button-click-container">
      <h1>Main App</h1>
      <button
        className="styled-button"
        onClick={() => handleButtonClick(1)}
      >
        Button 1
      </button>
      <button
        className="styled-button"
        onClick={() => handleButtonClick(2)}
      >
        Button 2
      </button>
      <button
        className="styled-button"
        onClick={() => handleButtonClick(3)}
      >
        Button 3
      </button>
      <p className="clicked-message">
        {clickedButton
          ? `Button #${clickedButton} was clicked`
          : 'Click any button!'}
      </p>
    </div>
  );
}

export default MainApp;
