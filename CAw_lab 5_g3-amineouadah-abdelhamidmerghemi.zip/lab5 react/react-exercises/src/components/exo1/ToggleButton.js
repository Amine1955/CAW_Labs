import React, { useState } from 'react';
import './ButtonClick.css'; // Reusing the styles

function ToggleButton() {
  const [toggled, setToggled] = useState(false);

  return (
    <div className="button-click-container">
      <button
        className={`styled-button ${toggled ? 'clicked' : ''}`} // Add the class here
        onClick={() => setToggled(!toggled)}
      >
        {toggled ? 'Not Clicked' : 'Click Me'}
      </button>
      <p className="clicked-message">
        {toggled ? '❌ Not Clicked!' : '✔️ Clicked!'}
      </p>
    </div>
  );
}

export default ToggleButton;
