import React, { useState } from 'react';
import './ButtonClick.css'; // Reusing the styles

function Counter() {
  const [count, setCount] = useState(0);

  return (
    <div className="button-click-container">
      <h1>{count}</h1>
      <button
        className="styled-button" // Add the class here
        onClick={() => setCount(count + 1)}
      >
        Inc
      </button>
      <button
        className="styled-button" // Add the class here
        onClick={() => setCount(count - 1)}
      >
        Dec
      </button>
    </div>
  );
}

export default Counter;
