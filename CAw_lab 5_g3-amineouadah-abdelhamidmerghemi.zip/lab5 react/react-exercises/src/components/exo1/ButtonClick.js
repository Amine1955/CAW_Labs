import React, { useState } from 'react';
import './ButtonClick.css'; // Import the CSS file for styling

function ButtonClick() {
  const [clicked, setClicked] = useState(false);

  return (
    <div className="button-click-container">
      <button 
        className={`styled-button ${clicked ? 'clicked' : ''}`}
        onClick={() => setClicked(true)}
      >
        Click Me
      </button>
      {clicked && <p className="clicked-message">✨ You Clicked! ✨</p>}
    </div>
  );
}

export default ButtonClick;
