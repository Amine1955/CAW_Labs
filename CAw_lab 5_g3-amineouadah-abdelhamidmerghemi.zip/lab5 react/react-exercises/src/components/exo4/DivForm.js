import React, { useState } from 'react';
import './DivStyle.css'; // New CSS for Exercise 4

function DivForm({ onAddDiv }) {
  const [height, setHeight] = useState('');
  const [width, setWidth] = useState('');
  const [bgColor, setBgColor] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (height && width && bgColor) {
      onAddDiv({ height, width, backgroundColor: bgColor });
      setHeight('');
      setWidth('');
      setBgColor('');
    }
  };

  return (
    <div className="form-container">
      <h3>Add a New Div</h3>
      <form onSubmit={handleSubmit}>
        <input
          type="number"
          placeholder="Height (px)"
          value={height}
          onChange={(e) => setHeight(e.target.value)}
          required
        />
        <input
          type="number"
          placeholder="Width (px)"
          value={width}
          onChange={(e) => setWidth(e.target.value)}
          required
        />
        <input
          type="color"
          value={bgColor}
          onChange={(e) => setBgColor(e.target.value)}
          required
        />
        <button type="submit" className="submit-button">
          Add Div
        </button>
      </form>
    </div>
  );
}

export default DivForm;
