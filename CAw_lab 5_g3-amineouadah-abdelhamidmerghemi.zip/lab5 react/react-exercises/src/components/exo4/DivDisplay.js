import React from 'react';
import './DivStyle.css'; // Reuse the CSS for the display

function DivDisplay({ divs }) {
  return (
    <div className="div-display-container">
      <h3>Divs Display</h3>
      <div className="div-list">
        {divs.map((div, index) => (
          <div
            key={index}
            style={{
              height: `${div.height}px`,
              width: `${div.width}px`,
              backgroundColor: div.backgroundColor,
            }}
            className="styled-div"
          >
            <span className="remove-text">X</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default DivDisplay;
