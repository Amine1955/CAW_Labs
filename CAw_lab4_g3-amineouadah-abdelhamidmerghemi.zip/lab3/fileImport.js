const mean = require('./notation');

// Example usage of the mean function
const scores1 = [90, 80, 70, 60, 50];
const average1 = mean(scores1);
console.log(`The mean of [${scores1}] is ${average1}`);